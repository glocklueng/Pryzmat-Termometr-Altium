/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : (C) Copyright
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC11xx.h"
#endif

#include <stdio.h>
extern unsigned long _etext;

int main(void)
{
	volatile unsigned long i=0;
	const unsigned long programSize = (unsigned long) &_etext;

	//SystemInit(); //Called by startup code

	printf("Hello World\n");
	printf("Size: %ld 0x%X\n", programSize, programSize);
	while(1)
	{
		i++;
		printf("i: %ld 0x%X\n", i, i);
	}
	return 0 ;
}
